﻿using NUnit.Framework;
using System;

namespace Skeleton.Tests
{
    [TestFixture]
    public class DummyTests
    {
        Dummy dummy;

        [SetUp]
        public void SetUp()
        {
            dummy = new(10, 1);
        }

        [Test]
        public void DummyShouldLoseHealthIfAttacked()
        {
            dummy.TakeAttack(1);

            Assert.That(dummy.Health, Is.EqualTo(9), "Dummy Doesn't lose health");
        }

        [Test]
        public void DummyShouldThrowExceptionIfAttackedWhenDead()
        {
            dummy.TakeAttack(10);

            InvalidOperationException ex = Assert.Throws<InvalidOperationException>(() => dummy.TakeAttack(1));

            Assert.AreEqual("Dummy is dead.", ex.Message, "Dummy dosn't throw exception");
        }

        [Test]
        [TestCase(10)]
        [TestCase(11)]
        public void DeadDummyShouldGiveXP(int damage)
        {
            dummy.TakeAttack(damage);

            Assert.AreEqual(1, dummy.GiveExperience(), "Dummy doesn't give experience");
        }

        [Test]
        [TestCase(9)]
        [TestCase(5)]
        public void AliveDummyShouldNotGiveXP(int damage)
        {
            dummy.TakeAttack(damage);

            InvalidOperationException ex = Assert.Throws<InvalidOperationException>(() => dummy.GiveExperience());

            Assert.AreEqual("Target is not dead.", ex.Message, "Dummy doesn't give experience");
        }
    }

}