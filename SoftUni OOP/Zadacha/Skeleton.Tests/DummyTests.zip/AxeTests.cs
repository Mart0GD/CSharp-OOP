using NUnit.Framework;
using System;

namespace Skeleton.Tests
{
    [TestFixture]
    public class AxeTests
    {
        [Test]
        [TestCase(10,1)]
        public void WeponShouldLoseDurabilityAfterEachAttack(int attack, int durability)
        {
            Axe axe = new Axe(attack, durability);

            axe.Attack(new Dummy(10,0));

            Assert.AreEqual(0, axe.DurabilityPoints);
        }

        [Test]
        [TestCase(10, 1)]
        public void WeponShouldNotAttckIfBroken(int attack, int durability)
        {
            Axe axe = new Axe(attack, durability);

            Dummy d = new Dummy(10, 0);

            axe.Attack(d);

            InvalidOperationException ex =  Assert.Throws<InvalidOperationException>(() => axe.Attack(d));

            Assert.AreEqual("Axe is broken.", ex.Message);
        }
    }
}