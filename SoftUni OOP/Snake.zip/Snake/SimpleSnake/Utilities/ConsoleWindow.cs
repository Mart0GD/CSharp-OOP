﻿namespace SimpleSnake.Utilities
{
    using System;
    using System.Text;
    using System.Runtime.InteropServices;

    public static class ConsoleWindow
    {
        internal static class DllImports
        {
            [StructLayout(LayoutKind.Sequential)]
            public struct COORD
            {

                public short X;
                public short Y;
                public COORD(short x, short y)
                {
                    this.X = x;
                    this.Y = y;
                }

            }
            [DllImport("kernel32.dll")]
            public static extern IntPtr GetStdHandle(int handle);
            [DllImport("kernel32.dll", SetLastError = true)]
            public static extern bool SetConsoleDisplayMode(
                IntPtr ConsoleOutput
                , uint Flags
                , out COORD NewScreenBufferDimensions
                );
        }

        public static void CustomizeConsole()
        {
            Console.OutputEncoding = Encoding.Unicode;
            IntPtr hConsole = DllImports.GetStdHandle(-11);   // get console handle
            DllImports.COORD xy = new DllImports.COORD(200, 200);
            DllImports.SetConsoleDisplayMode(hConsole, 1, out xy); // set the
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();
            Console.CursorVisible = false;
        }
    }
}
